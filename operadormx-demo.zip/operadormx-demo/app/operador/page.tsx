"use client";
import { useState } from "react";
import Link from "next/link";
import RiskMap from "@/components/RiskMap";
import { DRIVER_ROUTES } from "@/lib/data";

type Tab = "ruta" | "reportar" | "puntos";

export default function Operador() {
  const [online, setOnline] = useState(true);
  const [tab, setTab] = useState<Tab>("ruta");
  const [sosArmed, setSosArmed] = useState(false);
  const [queue, setQueue] = useState(0); // reportes en cola offline
  const [points, setPoints] = useState(620);

  function sendReport(kind: string) {
    if (online) {
      alert(`Reporte (${kind}) enviado. Alerta propagada a operadores en la 57.`);
      setPoints((p) => p + 80);
    } else {
      setQueue((q) => q + 1);
      setPoints((p) => p + 80);
    }
  }

  return (
    <div className="flex min-h-screen items-start justify-center bg-ink py-0 md:py-8">
      {/* Marco de teléfono (solo visible en desktop) */}
      <div className="relative w-full max-w-[400px] overflow-hidden bg-ink md:rounded-[2.2rem] md:border-[10px] md:border-[#1c1c1c] md:shadow-2xl">
        {/* status bar */}
        <div className="flex items-center justify-between px-5 pt-4 text-xs text-neutral-400">
          <span>9:41</span>
          <button
            onClick={() => setOnline((o) => !o)}
            className={`rounded-full px-2 py-0.5 ${online ? "text-safe" : "text-danger"}`}
          >
            {online ? "● Señal" : "✕ Sin señal"}
          </button>
        </div>

        {/* header */}
        <div className="px-5 pb-2 pt-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-neutral-500">Operadora</p>
              <p className="font-bold">María Solís · MX-4471</p>
            </div>
            <Link href="/" className="text-xs text-neutral-500">salir</Link>
          </div>
        </div>

        {/* banner offline */}
        {!online && (
          <div className="mx-5 mb-2 rounded-lg border border-danger/40 bg-danger/10 px-3 py-2 text-xs text-danger">
            Sin señal en la 57. Tu ubicación y reportes se guardan y se envían solos al recuperar red.
            {queue > 0 && <span className="ml-1 font-semibold">{queue} en cola.</span>}
          </div>
        )}

        {/* mapa siempre visible — pantalla 1 al abrir */}
        <div className="px-5">
          <RiskMap height={260} />
        </div>

        {/* SOS — la función crítica, siempre a la mano */}
        <div className="px-5 py-4">
          <button
            onClick={() => setSosArmed(true)}
            onPointerUp={() => sosArmed && setTimeout(() => setSosArmed(false), 1800)}
            className={`pulse w-full rounded-2xl py-5 text-center text-lg font-extrabold transition ${
              sosArmed ? "bg-danger text-white" : "bg-accent text-black"
            }`}
          >
            {sosArmed ? "ENVIANDO AUXILIO…" : "SOS · AUXILIO"}
          </button>
          <p className="mt-2 text-center text-[11px] text-neutral-500">
            Manda tu ubicación a la central y a unidades cercanas. Funciona sin señal por SMS.
          </p>
        </div>

        {/* tabs */}
        <div className="mx-5 mb-3 grid grid-cols-3 gap-1 rounded-xl bg-surface p-1 text-sm">
          {(["ruta", "reportar", "puntos"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-lg py-2 font-medium capitalize ${tab === t ? "bg-accent text-black" : "text-neutral-400"}`}
            >
              {t === "ruta" ? "Mi ruta" : t === "reportar" ? "Reportar" : "Puntos"}
            </button>
          ))}
        </div>

        <div className="px-5 pb-8">
          {tab === "ruta" && (
            <div className="space-y-3">
              {DRIVER_ROUTES.map((r) => (
                <div key={r.id} className="rounded-xl border border-line bg-carbon p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{r.label}</span>
                    <span className={`rounded px-2 py-0.5 text-xs ${
                      r.risk === "alto" ? "bg-danger/15 text-danger" : "bg-safe/15 text-safe"
                    }`}>{r.risk}</span>
                  </div>
                  <div className="mt-2 flex gap-4 text-xs text-neutral-400">
                    <span>{r.via}</span><span>{r.km} km</span><span>ETA {r.eta}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "reportar" && (
            <div className="space-y-3">
              <p className="text-sm text-neutral-400">¿Qué viste en la ruta?</p>
              {[
                ["Texto", "📝", "texto"],
                ["Audio (manos libres)", "🎙️", "audio"],
                ["Foto", "📷", "foto"],
              ].map(([label, icon, kind]) => (
                <button
                  key={kind}
                  onClick={() => sendReport(kind as string)}
                  className="flex w-full items-center gap-3 rounded-xl border border-line bg-carbon px-4 py-4 text-left hover:border-accent"
                >
                  <span className="text-xl">{icon}</span>
                  <span className="font-medium">{label}</span>
                  <span className="ml-auto text-xs text-accent">+80 pts</span>
                </button>
              ))}
              <p className="text-[11px] text-neutral-500">
                Por defecto sugerimos audio: el operador reporta sin soltar el volante.
              </p>
            </div>
          )}

          {tab === "puntos" && (
            <div>
              <div className="rounded-2xl bg-gradient-to-br from-accent to-[#cc5500] p-5 text-black">
                <span className="text-sm font-medium">Tus puntos paradero</span>
                <div className="text-4xl font-extrabold">{points}</div>
                <div className="mt-1 text-xs opacity-80">500 pts = baño + café gratis</div>
              </div>
              <p className="mt-4 mb-2 text-sm text-neutral-400">Canjeables ahora</p>
              <div className="space-y-2">
                {[
                  ["Baño + café", 500],
                  ["Regaderas 20 min", 800],
                  ["Comida corrida", 1200],
                ].map(([name, cost]) => {
                  const ok = points >= (cost as number);
                  return (
                    <div key={name as string} className="flex items-center justify-between rounded-xl border border-line bg-carbon px-4 py-3">
                      <span>{name}</span>
                      <button
                        disabled={!ok}
                        onClick={() => { setPoints((p) => p - (cost as number)); alert("QR de canje generado. Muéstralo en el paradero."); }}
                        className={`rounded-lg px-3 py-1.5 text-sm font-semibold ${ok ? "bg-accent text-black" : "bg-surface text-neutral-600"}`}
                      >
                        {cost} pts
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
