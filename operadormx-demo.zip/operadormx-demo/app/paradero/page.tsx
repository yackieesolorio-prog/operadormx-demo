"use client";
import { useState } from "react";
import Link from "next/link";
import { TODAY_REDEMPTIONS } from "@/lib/data";

export default function Paradero() {
  const [list, setList] = useState(TODAY_REDEMPTIONS);
  const [scan, setScan] = useState<null | { ok: boolean; msg: string }>(null);
  const [code, setCode] = useState("");

  function validate(input: string) {
    const c = input.trim().toUpperCase();
    // QR único: empieza con PRD- y no fue usado hoy
    const used = list.some((r) => r.code === c);
    if (!c.startsWith("PRD-")) {
      setScan({ ok: false, msg: "Código inválido. Pide al operador su QR de canje en la app." });
    } else if (used) {
      setScan({ ok: false, msg: `El código ${c} ya fue canjeado hoy.` });
    } else {
      const reward = "Baño + café";
      setScan({ ok: true, msg: `Válido. Entregar: ${reward}.` });
      setList((l) => [
        { id: `R-${Math.floor(Math.random() * 9000 + 1000)}`, driver: "Operador foráneo", unit: "—", reward, points: 500, time: new Date().toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }), code: c },
        ...l,
      ]);
    }
    setCode("");
  }

  const totalPoints = list.reduce((s, r) => s + r.points, 0);

  return (
    <main className="mx-auto min-h-screen max-w-3xl px-5 py-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="grid h-7 w-7 place-items-center rounded bg-black ring-1 ring-line">
            <span className="block h-3 w-3 rotate-45 bg-accent" />
          </span>
          <span className="text-sm font-bold">OPERADOR<span className="text-accent">MX</span> · Paradero El Mezquite</span>
        </div>
        <Link href="/" className="text-sm text-neutral-500 hover:text-white">salir</Link>
      </header>

      {/* Escanear / validar */}
      <section className="mt-6 rounded-2xl border border-line bg-carbon p-6 text-center">
        <div className="mx-auto grid h-32 w-32 place-items-center rounded-xl border-2 border-dashed border-accent/50 bg-surface">
          <span className="text-5xl">▦</span>
        </div>
        <p className="mt-3 text-sm text-neutral-400">Escanea el QR del operador o captura el código.</p>
        <div className="mx-auto mt-4 flex max-w-sm gap-2">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && validate(code)}
            placeholder="PRD-XXXX"
            className="flex-1 rounded-lg border border-line bg-surface px-3 py-2.5 text-sm outline-none focus:border-accent"
          />
          <button onClick={() => validate(code)} className="rounded-lg bg-accent px-4 py-2.5 text-sm font-semibold text-black">
            Validar
          </button>
        </div>
        <div className="mt-2 text-xs text-neutral-600">Prueba: <button onClick={() => validate("PRD-NEW1")} className="text-accent underline">PRD-NEW1</button></div>
        {scan && (
          <div className={`mx-auto mt-4 max-w-sm rounded-lg px-4 py-3 text-sm ${scan.ok ? "bg-safe/15 text-safe" : "bg-danger/15 text-danger"}`}>
            {scan.msg}
          </div>
        )}
      </section>

      {/* Resumen */}
      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="rounded-xl border border-line bg-carbon p-4">
          <div className="text-xs text-neutral-500">Canjes hoy</div>
          <div className="mt-1 text-3xl font-extrabold text-accent">{list.length}</div>
        </div>
        <div className="rounded-xl border border-line bg-carbon p-4">
          <div className="text-xs text-neutral-500">Puntos canjeados hoy</div>
          <div className="mt-1 text-3xl font-extrabold">{totalPoints.toLocaleString("es-MX")}</div>
        </div>
      </div>

      {/* Lista */}
      <section className="mt-6">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-neutral-400">Canjes de hoy</h2>
        <div className="overflow-hidden rounded-xl border border-line">
          <table className="w-full text-sm">
            <thead className="bg-surface text-left text-xs uppercase text-neutral-500">
              <tr><th className="px-4 py-2.5">Hora</th><th className="px-4 py-2.5">Código</th><th className="px-4 py-2.5">Servicio</th><th className="px-4 py-2.5 text-right">Pts</th></tr>
            </thead>
            <tbody>
              {list.map((r) => (
                <tr key={r.id} className="border-t border-line">
                  <td className="px-4 py-2.5 text-neutral-400">{r.time}</td>
                  <td className="px-4 py-2.5 font-mono text-xs">{r.code}</td>
                  <td className="px-4 py-2.5">{r.reward}</td>
                  <td className="px-4 py-2.5 text-right font-semibold text-accent">{r.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
