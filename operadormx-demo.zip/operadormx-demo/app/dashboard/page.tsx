"use client";
import { useState } from "react";
import Link from "next/link";
import RiskMap from "@/components/RiskMap";
import { FLEET, ALERTS, COST_BY_ROUTE } from "@/lib/data";

export default function Dashboard() {
  const [authQueue, setAuthQueue] = useState([{ id: "RT-09", route: "MX-8830 · CDMX → QRO (57)", driver: "Pedro Anaya" }]);
  const active = FLEET.filter((f) => f.status === "en_ruta").length;
  const openAlerts = ALERTS.filter((a) => a.level === "alto").length;
  const avgCost = Math.round(COST_BY_ROUTE.reduce((s, r) => s + r.costPerTrip, 0) / COST_BY_ROUTE.length);

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-ink/90 px-6 py-4 backdrop-blur">
        <div className="flex items-center gap-2.5">
          <span className="grid h-7 w-7 place-items-center rounded bg-black ring-1 ring-line">
            <span className="block h-3 w-3 rotate-45 bg-accent" />
          </span>
          <span className="text-sm font-bold">OPERADOR<span className="text-accent">MX</span> · Logística</span>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <span className="hidden text-neutral-400 sm:inline">Carolina Méndez · Jefa de logística</span>
          <Link href="/" className="text-neutral-500 hover:text-white">salir</Link>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 py-6">
        {/* KPIs — lo que necesita en 5 segundos */}
        <div className="grid gap-4 sm:grid-cols-3">
          <Kpi label="Camiones activos" value={`${active}/${FLEET.length}`} hint="2 en zona de riesgo" tone="accent" />
          <Kpi label="Alertas abiertas" value={String(openAlerts)} hint="prioridad alta" tone="danger" />
          <Kpi label="Costo prom. / ruta" value={`$${avgCost.toLocaleString("es-MX")}`} hint="últimos 30 días" tone="plain" />
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          {/* Mapa */}
          <section className="lg:col-span-2">
            <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-neutral-400">Flotilla en mapa</h2>
            <RiskMap height={360} />
            <div className="mt-4 overflow-hidden rounded-xl border border-line">
              <table className="w-full text-sm">
                <thead className="bg-surface text-left text-xs uppercase text-neutral-500">
                  <tr><th className="px-4 py-2.5">Unidad</th><th className="px-4 py-2.5">Operador</th><th className="px-4 py-2.5">Ruta</th><th className="px-4 py-2.5">Estado</th><th className="px-4 py-2.5">Riesgo</th></tr>
                </thead>
                <tbody>
                  {FLEET.map((f) => (
                    <tr key={f.id} className="border-t border-line">
                      <td className="px-4 py-2.5 font-medium">{f.id}</td>
                      <td className="px-4 py-2.5 text-neutral-400">{f.driver}</td>
                      <td className="px-4 py-2.5 text-neutral-400">{f.route}</td>
                      <td className="px-4 py-2.5"><Status s={f.status} /></td>
                      <td className="px-4 py-2.5"><Risk level={f.risk} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Alertas + autorizar */}
          <aside className="space-y-6">
            <section>
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-neutral-400">Alertas en vivo</h2>
              <div className="space-y-2.5">
                {ALERTS.map((a) => (
                  <div key={a.id} className="rounded-xl border border-line bg-carbon p-3.5">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold">{a.type}</span>
                      <Risk level={a.level} />
                    </div>
                    <p className="mt-1 text-xs text-neutral-400">{a.unit} · {a.where}</p>
                    <p className="mt-0.5 text-[11px] text-neutral-600">{a.time}</p>
                  </div>
                ))}
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-neutral-400">Autorizar ruta</h2>
              <p className="mb-2 text-xs text-neutral-500">Se autoriza desde compu o celular — la misma vista.</p>
              {authQueue.length === 0 ? (
                <div className="rounded-xl border border-dashed border-line p-5 text-center text-sm text-neutral-500">
                  Sin rutas pendientes.
                </div>
              ) : authQueue.map((r) => (
                <div key={r.id} className="rounded-xl border border-line bg-carbon p-4">
                  <p className="text-sm font-semibold">{r.route}</p>
                  <p className="text-xs text-neutral-400">{r.driver}</p>
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => setAuthQueue((q) => q.filter((x) => x.id !== r.id))}
                      className="flex-1 rounded-lg bg-accent py-2 text-sm font-semibold text-black"
                    >Autorizar</button>
                    <button
                      onClick={() => setAuthQueue((q) => q.filter((x) => x.id !== r.id))}
                      className="flex-1 rounded-lg border border-line py-2 text-sm font-medium text-neutral-400"
                    >Rechazar</button>
                  </div>
                </div>
              ))}
            </section>
          </aside>
        </div>

        {/* Reportes que hacen firmar el cheque */}
        <section className="mt-8">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-neutral-400">Reportes</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <Report title="Incidentes por corredor" desc="Robos, retenes y pérdidas de señal por ruta. Justifica seguir o cambiar de corredor.">
              {COST_BY_ROUTE.map((r) => (
                <Row key={r.route} a={r.route} b={`${r.incidents} incid.`} tone={r.incidents > 0 ? "danger" : "safe"} />
              ))}
            </Report>
            <Report title="Costo por ruta" desc="Costo promedio por viaje. Permite comparar rentabilidad real entre corredores.">
              {COST_BY_ROUTE.map((r) => (
                <Row key={r.route} a={r.route} b={`$${r.costPerTrip.toLocaleString("es-MX")}`} />
              ))}
            </Report>
            <Report title="Cumplimiento NOM-087" desc="Horas de manejo por operador. Evita multas y respalda a la empresa ante un siniestro.">
              <Row a="Dentro de norma" b="92%" tone="safe" />
              <Row a="En alerta" b="6%" tone="accent" />
              <Row a="Excedido" b="2%" tone="danger" />
            </Report>
          </div>
        </section>
      </div>
    </main>
  );
}

function Kpi({ label, value, hint, tone }: { label: string; value: string; hint: string; tone: "accent" | "danger" | "plain" }) {
  const ring = tone === "danger" ? "border-danger/40" : tone === "accent" ? "border-accent/40" : "border-line";
  const val = tone === "danger" ? "text-danger" : tone === "accent" ? "text-accent" : "text-white";
  return (
    <div className={`rounded-2xl border ${ring} bg-carbon p-5`}>
      <div className="text-xs uppercase tracking-wide text-neutral-500">{label}</div>
      <div className={`mt-1 text-4xl font-extrabold ${val}`}>{value}</div>
      <div className="mt-1 text-xs text-neutral-500">{hint}</div>
    </div>
  );
}

function Status({ s }: { s: string }) {
  const map: Record<string, [string, string]> = {
    en_ruta: ["En ruta", "text-safe"],
    parada: ["Parada", "text-neutral-400"],
    sin_senal: ["Sin señal", "text-danger"],
  };
  const [t, c] = map[s] ?? ["—", "text-neutral-400"];
  return <span className={`text-xs ${c}`}>● {t}</span>;
}

function Risk({ level }: { level: string }) {
  const map: Record<string, string> = {
    alto: "bg-danger/15 text-danger", medio: "bg-accent/15 text-accent", bajo: "bg-safe/15 text-safe",
  };
  return <span className={`rounded px-2 py-0.5 text-xs font-medium ${map[level]}`}>{level}</span>;
}

function Report({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-line bg-carbon p-5">
      <h3 className="font-bold">{title}</h3>
      <p className="mt-1 text-xs text-neutral-500">{desc}</p>
      <div className="mt-3 space-y-1.5">{children}</div>
    </div>
  );
}

function Row({ a, b, tone }: { a: string; b: string; tone?: "danger" | "safe" | "accent" }) {
  const c = tone === "danger" ? "text-danger" : tone === "safe" ? "text-safe" : tone === "accent" ? "text-accent" : "text-neutral-300";
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="truncate pr-2 text-neutral-400">{a}</span>
      <span className={`font-semibold ${c}`}>{b}</span>
    </div>
  );
}
